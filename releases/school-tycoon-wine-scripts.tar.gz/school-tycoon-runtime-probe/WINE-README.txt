School Tycoon Windows CPU diagnostic

Prerequisite: the earlier Box64 CPU diagnostic has passed on the handheld.
Extract this scripts archive into /userdata/roms/ports/. It adds two scripts to
the existing school-tycoon-runtime-probe directory. Keep the existing box64 file.

Through SSH:
  cd /userdata/roms/ports/school-tycoon-runtime-probe
  sh prepare-wine.sh
  sh test-wine.sh

Preparation requires Internet access, curl, sha256sum, tar with XZ support,
and at least 2 GiB free. It downloads approximately 95 MiB and verifies its
pinned SHA-256 before extracting Wine. No system packages or firmware change.
An existing Wine directory is left untouched. The test creates a dedicated
prefix inside this diagnostic directory. Allow several minutes on first run.

Send logs/wine.txt. If a stage fails, also retain logs/wine-64.txt and
logs/wine-32.txt, plus any terminal error. No need to upload game assets again.

This tests 64-bit and 32-bit Windows command execution only. Graphics, audio,
controls, and game compatibility are not tested. The game is not launched.

Update for the missing libgcc_s.so.1 error:
This package now includes the x86_64 support library and updates the diagnostic
search path. If Wine is already installed, rerun only sh test-wine.sh.
Do not delete the Wine directory or prefix.

Wine publisher: https://github.com/Kron4ek/Wine-Builds/releases/tag/11.19
Build: wine-11.19-amd64-wow64.tar.xz
SHA256: a1fe858b45d12c9b16b91c7601d9b934f68430f7b6b95e240212ab6e2a198d8a

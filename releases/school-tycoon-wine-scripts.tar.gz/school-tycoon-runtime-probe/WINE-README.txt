School Tycoon Windows CPU diagnostic

Prerequisite: the earlier Box64 CPU diagnostic has passed on the handheld.
Extract this scripts archive into /userdata/roms/ports/. It adds two scripts to
the existing school-tycoon-runtime-probe directory. Keep the existing box64 file.

Through SSH:
  cd /userdata/roms/ports/school-tycoon-runtime-probe
  sh prepare-wine.sh
  sh test-wine.sh

Preparation requires Internet access, curl, sha256sum, tar with XZ support,
and at least 2 GiB free. It downloads approximately 62 MiB and verifies its
pinned SHA-256 before extracting Wine. No system packages or firmware change.
An existing Wine directory is left untouched. The test creates a dedicated
prefix inside this diagnostic directory. Allow several minutes on first run.

Send logs/wine.txt. If a stage fails, also retain logs/wine-64.txt and
logs/wine-32.txt, plus any terminal error. No need to upload game assets again.

This tests 64-bit and 32-bit Windows command execution only. Graphics, audio,
controls, and game compatibility are not tested. The game is not launched.

Update for Wine 11.19's memory-allocation assertion:
This package now selects stable Wine 10.0 in its own directory and prefix.
Run BOTH preparation and testing, even if Wine 11.19 is already installed.
Do not delete the existing Wine 11.19 directory or prefix. The x86_64 libgcc
support library from the previous fix is retained. This workaround still needs
verification on the handheld.

Wine publisher: https://github.com/Kron4ek/Wine-Builds/releases/tag/10.0
Build: wine-10.0-amd64-wow64.tar.xz
SHA256: aeebbbf239e548f0136f1cd72a2e109dd9a572a8f703da3c09fa40d74d5c255f

Update for markers printed but exit 137:
After extracting these updated scripts, no Wine download is needed if 10.0 is
already installed. Run from this diagnostic directory:
  sh test-wine.sh strongmem || sh test-wine.sh interpreter

Send logs/wine-strongmem.txt and logs/wine-interpreter.txt if the latter ran.
Strongmem enables documented memory barriers; interpreter disables the dynamic
recompiler. Both are diagnostic hypotheses, not confirmed fixes. Commands have
120-second timeouts plus a 5-second kill grace. The log includes elapsed time,
memory counters, and available OOM reports. A printed marker with nonzero exit
is still a failed test. No game, firmware, or system package changes are made.

Native graphics stage (after interpreter-mode Windows commands pass):
  sh test-graphics.sh
Send logs/graphics.txt. It runs the included native ARM64 EGL/GLES2 pbuffer
readback probe and records driver/runtime metadata. No Wine download, visible
window, Weston startup, or game execution is involved. Failure output is useful.
This native test does not establish Wine, GLX, Direct3D 8, or gameplay support.
The probe's source is available in the GitHub repository under tools/.

Windows window stage (after native EGL/GLES passes):
  sh test-window.sh
Send logs/window.txt and logs/window-weston.txt. It verifies and extracts the
installed Weston image into this diagnostic folder (approximately 133 MiB),
starts a private headless compositor, and runs a 32-bit Windows GDI pixel test
using the verified interpreter mode. No physical window appears on the screen.
The command must produce its generated marker and exit zero. Allow several
minutes for startup. No upstream wrapper, fake DRM device, global process kill,
game asset changes, or firmware changes are used. Direct3D remains untested.

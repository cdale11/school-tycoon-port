School Tycoon ARM64 CPU runtime diagnostic

This is a prerequisite test, not a playable game or a complete PortMaster port.
No game files are included. It does not install packages or modify firmware.

1. Extract this archive into /userdata/roms/ports/ on your RG34XXSP.
2. Through SSH, run:
   sh /userdata/roms/ports/school-tycoon-runtime-probe/test-box64.sh
3. Provide this generated log:
   /userdata/roms/ports/school-tycoon-runtime-probe/logs/box64.txt

If the script fails, still provide the log and any terminal error.
Success ends with "CPU diagnostic completed successfully."
This establishes x86_64 CPU translation only. Wine, 32-bit Windows code,
Direct3D 8, audio, controller input, and game performance remain untested.

Box64 source: https://github.com/ptitSeb/box64
Commit: 45f85efc52d7bd3a3c8642bfc5093ce7932f6c23
License: MIT, included in BOX64-LICENSE.
Build: generic ARM64, ARM dynamic recompiler enabled, Release, Box32 disabled.
Compiler: Debian GCC 14.2.0 AArch64 cross compiler.
Required loader: /lib/ld-linux-aarch64.so.1
Direct shared dependencies: libc.so.6, libm.so.6, libresolv.so.2.
Highest referenced glibc symbol version: GLIBC_2.39.
Cloud validation: --version and execution probes passed under QEMU AArch64.
The actual handheld has not yet executed this binary.

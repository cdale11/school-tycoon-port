-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA512

Format: 3.0 (quilt)
Source: libmspack
Binary: libmspack0, libmspack-dev, libmspack-doc
Architecture: any all
Version: 0.11-1
Maintainer: Marc Dequènes (Duck) <Duck@DuckCorp.org>
Homepage: https://www.cabextract.org.uk/libmspack/
Standards-Version: 4.6.2
Vcs-Browser: https://salsa.debian.org/debian/libmspack
Vcs-Git: https://salsa.debian.org/debian/libmspack.git
Build-Depends: dpkg-dev (>= 1.16.1.1), debhelper-compat (= 12)
Build-Depends-Indep: doxygen, graphviz
Package-List:
 libmspack-dev deb libdevel optional arch=any
 libmspack-doc deb doc optional arch=all
 libmspack0 deb libs optional arch=any
Checksums-Sha1:
 4ff621c71ecfb07007a1d7ff9d9aabf41ac1d755 509478 libmspack_0.11.orig.tar.gz
 117f6e880e9290b658cc3b908e4df6e8909440d9 3868 libmspack_0.11-1.debian.tar.xz
Checksums-Sha256:
 70dd1fb2f0aecc36791b71a1e1840e62173079eadaa081192d1c323a0eeea21b 509478 libmspack_0.11.orig.tar.gz
 923d6b5cae88206464a2f2483830b2e1687890180088ddf35bfcc8297db3cc85 3868 libmspack_0.11-1.debian.tar.xz
Files:
 3e770746e8eebba9ac4ce965e69dd107 509478 libmspack_0.11.orig.tar.gz
 8d6050aa88e0d23d656325b8ab880cfc 3868 libmspack_0.11-1.debian.tar.xz

-----BEGIN PGP SIGNATURE-----

iQIzBAEBCgAdFiEEcpcqg+UmRT3yiF+BVen596wcRD8FAmPieh0ACgkQVen596wc
RD9sOw//RBm2YGGzKK3kLOo6Mrt+V9UdkqhLzs4/bZY4/Ajh5orreO3DwjmQPpbR
zQ3VUb5vZi/Jcc11s6FEufuEtKOzS6AG8+BhabiIIT3wpoN0ugV0Y8mRQ4f7eLIZ
dbhvMQ0WXC/aX1JbSRQHCQFW65PPcigFaAoy5VOpc3Gh83XnPUuAxTLelNLpeJKr
wxL93qzfSU9b3n8J5uI8cRXZTNTfyPtea61xwyn2PcyWiLV/KiMg7D8t6mLQoqx6
h0UNIw6ZuPgtwW3k82sJTB5nN2EWFqkj9uPAjSiGng17uIhRfrYzSwSNe1jrPeXI
6nEZc/9hFe/oZjimgnW/5UzdlstIwESozs7I7MkUC2QUWWBmeFRynJUXt4XZ3FyT
0doiivvd2c7ccFMznXFCOUj01PQdH5iSoKMhYk5a/GJS4OUWWYMV21oFyHX2Eo8e
tU2V15JWmLo54434X+oDw+bn9SEwzfy23tr9jJGGMJM/cY/ABHZHA+y0DNlulk09
ehFkbD0fxfXLRkBxTsTJqBWh3wAMt9cb23LgxwsejsuwOnlef+4jsdhSwEV2BbX2
21nTOcJ3b+S7JZd28PhIH5mc3afp6zyIDxfsm6zAWYOd/p1UPIAILvy3aYVQ4jGv
WH0N0s4h6lc6mr1h44a9M4G1cHx70ux1IyQ1/wRcv0aZCqIM+Ik=
=YUcB
-----END PGP SIGNATURE-----
